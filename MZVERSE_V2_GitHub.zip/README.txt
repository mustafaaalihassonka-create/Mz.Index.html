MZVERSE V2 - GitHub Pages
ارفع index.html و music.mp4 إلى نفس الـ Repository.
ثم Settings > Pages > Deploy from branch > main > / (root).
الموسيقى مأخوذة من الملف الذي رفعته في المحادثة، وتعمل عند الضغط على زر ♫.
